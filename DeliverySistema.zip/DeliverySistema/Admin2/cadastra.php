<?php

$categoria = $_POST['categoria'];
$produto = $_POST['produto'];
$ingredientes = $_POST['ingredientes'];
$preco = $_POST['preco'];

// verifica se foi enviado um arquivo
if (isset($_FILES['imagem']['name']) && $_FILES['imagem']['error'] == 0) {

    $arquivo_tmp = $_FILES['imagem']['tmp_name'];
    $nome = $_FILES['imagem']['name'];

    // Pega a extensão
    $extensao = pathinfo($nome, PATHINFO_EXTENSION);

    // Converte a extensão para minúsculo
    $extensao = strtolower($extensao);

    // Somente imagens, .jpg;.jpeg;.png;
    // Aqui eu enfileiro as extensões permitidas e separo por ';'
    // Isso serve apenas para eu poder pesquisar dentro desta String
    if (strstr('.jpg;.jpeg;.png', $extensao)) {
        // Cria um nome único para esta imagem
        // Evita que duplique as imagens no servidor.
        // Evita nomes com acentos, espaços e caracteres não alfanuméricos
        $novoNome = uniqid(time()) . '.' . $extensao;

        // Concatena a pasta com o nome
        $destino = '../Delivery/imagens/' . $novoNome;
        //Salvando o arquivo na pasta
        if (!move_uploaded_file($arquivo_tmp, $destino)) {
            echo 'Erro ao salvar o arquivo. ';
        }
        
        $conexao = mysqli_connect("localhost", "root", "", "delivery") or die("Erro na conexão com banco de dados");

        $sql = "INSERT INTO `produtos` (`idCateg`, `caminhoImagem`, `nome`,`ingredientes`, `preco`) VALUES";
        $sql .= "('$categoria', '$novoNome', '$produto', '$ingredientes', '$preco')"; 

        mysqli_query($conexao, $sql) or die("Erro ao tentar cadastrar registro");
    } else {
        echo 'Você poderá enviar apenas arquivos "*.jpg;*.jpeg;*.png"' . "<br/>";
    }
} else {
    $conexao = mysqli_connect("localhost", "root", "", "delivery") or die("Erro na conexão com banco de dados");

    $sql = "INSERT INTO `produtos` (`idCateg`, `nome`,`ingredientes`, `preco`) VALUES";
    $sql .= "('$categoria', '$produto', '$ingredientes', '$preco')";

    mysqli_query($conexao, $sql) or die("Erro ao tentar cadastrar registro");
}

mysqli_close($conexao);

header('Location: cadastrarProduto.php');