<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Admin</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

        <link rel="stylesheet" href="css/style.css">

        <link rel="stylesheet" href="css/mdb.css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <!-- Google Font -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    </head>
    <body class="hold-transition skin-purple sidebar-mini">
        <div class="wrapper">

            <header class="main-header">
                <!-- Logo -->
                <a href="index.html" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>A</b>GP</span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><b>Admin</b> Grasper</span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                    </a>
                </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                        </div>
                        <div class="pull-left info">
                            <p>Alexander Pierce</p>
                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu" data-widget="tree">
                        <li class="header">Navegação</li>
                        <li>
                            <a href="index.html">
                                <i class="fa fa-dashboard"></i> <span>Pedidos</span>
                            </a>
                        </li>
                        <li class="active">
                            <a href="cadastrarProduto.php">
                                <i class="fa fa-dashboard"></i> <span>Cadastrar Produto</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Cadastrar Produto</li>
                    </ol>
                </section>

                <!-- Main content -->
                <form class="container" method="post" enctype="multipart/form-data" action="cadastra.php">
                    <br><br>
                    <table style="border-collapse: separate; border-spacing: 10px;">
                        <tr>
                            <td>
                                <label>Selecione uma imagem:</label> 
                            </td>
                            <td>
                                <input name="imagem" type="file" accept="image/*"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Categoria:</label>
                            </td>
                            <td>
                                <select name="categoria">
                                    <?php
                                    $conexao = mysqli_connect("localhost", "root", "", "delivery") or die("Erro na conexão com banco de dados");
                                    $sql = "SELECT * FROM categorias";
                                    $res = mysqli_query($conexao, $sql);

                                    while ($reg = mysqli_fetch_assoc($res)) {
                                        $id = $reg['idCategoria'];
                                        $categoria = $reg['nomeCategoria'];

                                        echo '<option value="' . $id . '">' . $categoria . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Nome do produto:</label>
                            </td>
                            <td>
                                <input name="produto" type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Ingredientes:</label>
                            </td>
                            <td>
                                <input name="ingredientes" type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Preço:</label>
                            </td>
                            <td>
                                <input name="preco" type="number" />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" value="Cadastrar" />
                            </td>
                        </tr>
                    </table>
                </form>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
            <footer class="main-footer">
                <strong>Copyright &copy; <a href="#">Grasper</a>.</strong> Todos os direitos reservados.
            </footer>
            <!-- Add the sidebar's background. This div must be placed
                 immediately after the control sidebar -->
        </div>
        <!-- ./wrapper -->

        <!-- jQuery 3 -->
        <script src="js/bootstrap.min.js"></script>

        <script src="js/jquery-1.11.1.min.js"></script>

        <script src="js/style.js"></script>

        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <script>
            $.widget.bridge('uibutton', $.ui.button);
        </script>

        <!-- AdminLTE App -->
        <script src="dist/js/adminlte.min.js"></script>
    </body>
</html>
