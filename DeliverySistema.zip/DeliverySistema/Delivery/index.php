<!DOCTYPE html>
<html lang="PT-BR">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Sandubão Lanches">
        <meta name="keywords" content="Lanche, Comida, Pizza">
        <meta name="author" content="Grasper">
        <title>Sandubão Lanches</title>

        <!--CABEÇALHO-->
        
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet" type="text/css">

        <!--PRODUTOS-->
        <link href="https://fonts.googleapis.com/css?family=Muli:300,400,600,700" rel="stylesheet">        
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/flaticon.css">
        

        <!--RODAPÉ-->
        <link rel="stylesheet" href="css/icomoon.css">
        
        <!--TODOS-->
        <link rel="stylesheet" href="css/style.css"> <!--Bootstrap-->
        
    </head>
    <!-- Navigation -->
    <body>
        <div>
            <header class="topbar">
                <div class="container">
                    <div class="row">
                        <!-- social icon-->
                        <div class="col-sm-12">
                            <div>
                                <div>
                                    <h1 class="fechado" style="text-transform: capitalize;">Fechado agora</h1>
                                </div>
                            </div>
                            <ul class="social-network">
                                <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
            <nav class="navbar navbar-expand-lg navbar-dark mx-background-top-linear">
                <div class="container">
                    <a href="index.php">
                        <img class="logo" src="https://dmmzi9kl6wusl.cloudfront.net/sandubaolanches64/uploads/&#10;82afb3e057ce6f3d976ac5adbab24a99.png" alt="Sandubão">
                    </a>
                    <a class="fontelogo" href="index.php">Sandubão<br>Lanches</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link text-capitalize" href="index.php">Cardápio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-capitalize" href="#">Horário de funcionamento</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-capitalize" href="#">Regiões de entrega</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-capitalize" href="#">Contato</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-capitalize" href="javascript: doMyAccountClick()">Minha conta</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <section class="ftco-section bg-light">
            <div class="container">
                <div class="row justify-content-center mb-5">
                    <div class="col-md-7 text-center heading-section ftco-animate fadeInUp ftco-animated">
                        <span class="subheading">Nosso Cardápio</span>
                        <h2>Descubra Nosso Menu Exclusivo</h2>
                    </div>
                </div>
                <div class="row">
                    <div id="form" class="col-md-12 dish-menu">
                        <div class="nav nav-pills justify-content-center ftco-animate fadeInUp ftco-animated" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <?php include_once 'categoria.php'; ?>
                        </div>
                        <div class="tab-content py-5" id="v-pills-tabContent">
                            <?php include_once 'produtos.php'; ?>                     
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer -->
        <footer class="ftco-footer ftco-bg-dark ftco-section">
            <div class="container">
                <div class="row mb-5">
                    <div class="col-md">
                        <div class="ftco-footer-widget mb-4">
                            <h2 class="ftco-heading-2">Sandubão Lanches</h2>
                            <p>Breve descrição do negócio.</p>
                            <ul class="ftco-footer-social list-unstyled float-md-left float-lft">
                                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="ftco-footer-widget mb-4">
                            <h2 class="ftco-heading-2">Horário de Funcionamento</h2>
                            <ul class="list-unstyled">
                                <li><a href="#" class="py-2 d-block">Segunda: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Terça: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Quarta: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Quinta: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Sexta: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Sábado: <span>08:00 - 22:00</span></a></li>
                                <li><a href="#" class="py-2 d-block">Domingo: <span>08:00 - 22:00</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="ftco-footer-widget mb-4">
                            <h2 class="ftco-heading-2">Informações de Contato</h2>
                            <ul class="list-unstyled">
                                <li><a href="#" class="py-2 d-block">Endereço</a></li>
                                <li><a href="#" class="py-2 d-block">(00) 0000-0000</a></li>
                                <li><a href="#" class="py-2 d-block">email@email.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="ftco-footer-widget mb-4">
                            <h2 class="ftco-heading-2">Contato por Email</h2>
                            <form action="#" class="subscribe-form">
                                <div class="form-group">
                                    <span class="icon icon-paper-plane"></span>
                                    <input type="text" class="form-control" placeholder="Email...">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos os direitos reservados | <a href="https://www.lojawinstore.com.br" target="_blank"><b>Grasper</b></a></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- ./Footer -->
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <!--script src="js/style.js" type="text/javascript"></script>
        <script src="js/bibliotecaAjax.js" type="text/javascript"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script-->
    </body>
</html>