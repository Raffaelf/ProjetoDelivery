<?php

$conexao = mysqli_connect("localhost", "root", "", "delivery") or die("Erro na conexão com banco de dados");

$sql = "SELECT * FROM categorias";

$res = mysqli_query($conexao, $sql);

$i = true;

$html = '';

while($reg = mysqli_fetch_assoc($res)){
    $id = $reg['idCategoria'];
    $categoria = $reg['nomeCategoria'];
    
    if($i == true){
        $html .= '<a class="nav-link py-3 px-4 active show" id="v-pills-' . $id . '-tab" data-toggle="pill" href="#v-pills-' . $id . '" role="tab" aria-controls="v-pills-' . $id . '" aria-selected="true"><span class="flaticon-meat"></span> ' . $categoria . '</a>' . "\n";
    }else{
        $html .= "\t\t\t\t\t\t\t" . '<a class="nav-link py-3 px-4" id="v-pills-' . $id . '-tab" data-toggle="pill" href="#v-pills-' . $id . '" role="tab" aria-controls="v-pills-' . $id . '" aria-selected="false"><span class="flaticon-cutlery"></span> ' . $categoria . '</a>' . "\n";
    }
    $i = false;
}

mysqli_close($conexao);

$meuHTML = utf8_encode($html);

echo $meuHTML;