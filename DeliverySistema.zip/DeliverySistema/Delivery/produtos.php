<?php

$conexao = mysqli_connect("localhost", "root", "", "delivery") or die("Erro na conexão com banco de dados");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$sql = "SELECT * FROM categorias";

$res = mysqli_query($conexao, $sql);

$html = '';

$j = 0;

while ($reg = mysqli_fetch_assoc($res)) {
    $id = $reg['idCategoria'];
    
    if ($j == 0) {
        $html .= '<div class="tab-pane fade active show" id="v-pills-' . $id . '" role="tabpanel" aria-labelledby="v-pills-' . $id . '-tab">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t" . '<div class="col-lg-6">'. "\n";
        $j++;
    } else {
        $html .= "\t\t\t\t\t\t\t" . '<div class="tab-pane fade" id="v-pills-' . $id . '" role="tabpanel" aria-labelledby="v-pills-' . $id . '-tab">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t" . '<div class="row">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t" . '<div class="col-lg-6">' . "\n";
    }

    $sql = 'SELECT produtos.caminhoImagem, produtos.nome, produtos.ingredientes, produtos.preco FROM produtos INNER JOIN categorias ON categorias.idCategoria = produtos.idCateg WHERE idCategoria = ' . $id;

    if($rs = mysqli_query($conexao, $sql)){
        $numrows = mysqli_num_rows($rs);
        $numrows = ceil($numrows/2);
        $i = 0;
    }
    
    while ($reg = mysqli_fetch_assoc($rs)) {
        $imagem = $reg['caminhoImagem'];
        $nome = $reg['nome'];
        $ingredientes = $reg['ingredientes'];
        $preco = number_format($reg['preco'], 2, ",", ".");
        
        $i++;

        $html .= "\t\t\t\t\t\t\t\t\t\t" . '<div class="menus d-flex ftco-animate fadeInUp ftco-animated">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t" . '<div class="menu-img" style="background-image: url(imagens/' . $imagem . ');"></div>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t" . '<div class="text d-flex">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="one-half">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<h3>' . $nome . '</h3>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<p>' . $ingredientes . '</p>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t" . '<div class="one-forth">' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t\t" . '<span class="price"> R$' . $preco . '</span>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
        $html .= "\t\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
        
        if($i == $numrows){
            $html .= "\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
            $html .= "\t\t\t\t\t\t\t\t\t" . '<div class="col-lg-6">' . "\n";
        }
    }
    
    $html .= "\t\t\t\t\t\t\t\t\t" . '</div>' . "\n";
    $html .= "\t\t\t\t\t\t\t\t" . '</div>' . "\n";
    $html .= "\t\t\t\t\t\t\t" . '</div>' . "\n";
    $html .= "\t\t\t\t\t\t\t" . '<!-- END -->' . "\n";
}

mysqli_close($conexao);

$meuHTML = utf8_encode($html);

echo $meuHTML;

?>